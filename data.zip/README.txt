
WALS Online data dump
=====================

Data of WALS Online is published under the following license:
http://creativecommons.org/licenses/by-nc-nd/2.0/de/deed.en

It should be cited as

Dryer, Matthew S. & Haspelmath, Martin (eds.) 2013.
The World Atlas of Language Structures Online.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://wals.info, Accessed on 2014-07-22.)


This package contains files in csv format [1] with corresponding schema descriptions in
JSON table schema [2] format, representing rows in database tables of the WALS Online web
application [3,4].

[1] http://csvlint.io/about
[2] http://dataprotocols.org/json-table-schema/
[3] http://wals.info
[4] https://github.com/clld/wals
