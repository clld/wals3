
WALS Online data dump
=====================

Data of WALS Online is published under the following license:
http://creativecommons.org/licenses/by/4.0/

It should be cited as

Dryer, Matthew S. & Haspelmath, Martin (eds.) 2013.
The World Atlas of Language Structures Online.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://wals.info, Accessed on 2015-07-22.)


This package contains files in csv format [1] with corresponding schema
descriptions according to [2], representing rows in database tables of
the WALS Online web application [3,4].

[1] http://www.w3.org/TR/tabular-data-model/#syntax
[2] http://www.w3.org/TR/tabular-metadata/
[3] http://wals.info
[4] https://github.com/clld/wals
